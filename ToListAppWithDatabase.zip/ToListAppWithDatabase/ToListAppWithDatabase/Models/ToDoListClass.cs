﻿
    using System;
    using System.ComponentModel.DataAnnotations;

namespace ToListAppWithDatabase.Models
    {
        public class ToDoListClass
        {
            [Key]
            public int Id { get; set; } // Primary Key

            [Required]
            [StringLength(100)]
            public string Title { get; set; } // Title of the task

            [StringLength(500)]
            public string Description { get; set; } // Detailed description of the task

            [DataType(DataType.Date)]
            public DateTime DueDate { get; set; } // Due date for the task

            public bool IsCompleted { get; set; } // Status of the task (completed or not)

            public PriorityLevel Priority { get; set; } // Priority level of the task
        }

        public enum PriorityLevel
        {
            Low,
            Medium,
            High
        }
    }


