﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ToListAppWithDatabase.Models;

namespace ToListAppWithDatabase.Data
{
    public class ToListAppContext : DbContext
    {
        public ToListAppContext (DbContextOptions<ToListAppContext> options)
            : base(options)
        {
        }

        public DbSet<ToListAppWithDatabase.Models.ToDoListClass> ToDoListClass { get; set; } = default!;
    }
}
